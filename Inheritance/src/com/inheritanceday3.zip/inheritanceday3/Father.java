package com.inheritanceday3;

public class Father extends GrandFather{
 public void showFather() {
	 System.out.println("This is a method of Father");
 }
}
