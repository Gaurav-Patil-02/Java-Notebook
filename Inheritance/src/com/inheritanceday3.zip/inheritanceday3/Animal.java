package com.inheritanceday3;

public class Animal {
	public void makeSound() {
		System.out.println("Some animal is Making Sound...");
	}
}
