package com.inheritanceday3;

public class Circle extends Shape {
	public void area(float radius) {
		System.out.println("Area of Circle : " + 3.14 * (radius * radius));
	}
}
