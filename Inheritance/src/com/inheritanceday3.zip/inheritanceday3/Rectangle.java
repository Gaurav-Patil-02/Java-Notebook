package com.inheritanceday3;

public class Rectangle extends Shape {
	public void area(int length, int width) {
		System.out.println("Area of Rectangle : " + (length * width));
	}
}
