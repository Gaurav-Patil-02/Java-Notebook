package com.inheritanceday3;

public class Person {
	public void  personInfo() {
		System.out.println("This is a person");
	}
}
