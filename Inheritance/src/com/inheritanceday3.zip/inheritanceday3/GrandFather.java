package com.inheritanceday3;

public class GrandFather {
 public void showGrandfather() {
	 System.out.println("This is a method of GrandFather...");
 }
}
