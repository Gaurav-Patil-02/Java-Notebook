package com.inheritanceday3;

public class Shape {
	 public void itsShape() {
		 System.out.println("This is an shape");
	 }
}
