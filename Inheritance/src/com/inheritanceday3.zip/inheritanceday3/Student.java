package com.inheritanceday3;

public class Student extends Person {
	public void studentInfo() {
		System.out.println("This is a Student");
	}
}
