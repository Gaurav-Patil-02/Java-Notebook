package com.inheritanceday3;

public class Employee extends Person {
	public void empInfo() {
		System.out.println("This is an employee");
	}
}
