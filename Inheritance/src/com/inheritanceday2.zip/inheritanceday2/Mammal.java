package com.inheritanceday2;

public class Mammal extends Animal {
	public void walk() {
		System.out.println("Mammal is Walking...");
	}
}
