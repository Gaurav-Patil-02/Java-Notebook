package com.inheritanceday2;

public class FourWheeler extends Vehicle {
	public void musicPlayer() {
		System.out.println("This Fourwheeler has a music player");
	}
}
