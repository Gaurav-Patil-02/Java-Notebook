package com.inheritanceday2;

public class Animal {
  public void eat() {
	  System.out.println("Animal is Eating");
}
}
