package com.inheritanceday2;

public class Device {
	public void powerOn() {
		System.out.println("Power On.....");
	}
}
