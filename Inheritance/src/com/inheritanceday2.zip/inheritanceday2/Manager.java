package com.inheritanceday2;

public class Manager {
	
	public void displayManager() {
		System.out.println("Inside method of Manager");
	}
	
}
