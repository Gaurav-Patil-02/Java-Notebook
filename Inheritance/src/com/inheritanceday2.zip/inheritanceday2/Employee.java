package com.inheritanceday2;

public class Employee extends Manager {
	public void displayEmployee() {
		System.out.println("Inside Method of Employee");
	}
}
