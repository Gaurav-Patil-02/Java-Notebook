package com.inheritanceday2;

public class Shape2 {
	public void draw() {
		System.out.println("Drawing a Shape");
	}
}
