package com.inheritanceday2;

public class Shape {
	public void displayShape() {
		System.out.println("This is an Shape");
	}
}
