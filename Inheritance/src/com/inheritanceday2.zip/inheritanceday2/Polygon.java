package com.inheritanceday2;

public class Polygon extends Shape{
	public void showPolygon() {
		System.out.println("This is an Polygon");
	}
}
