package com.inheritanceday2;

public class Vehicle {
	public void move() {
		System.out.println("This Vehicle is Moving....");
	}
}
