package com.inheritanceday2;

public class Mobile {
	public void call() {
		System.out.println("Calling....");
	}
}
