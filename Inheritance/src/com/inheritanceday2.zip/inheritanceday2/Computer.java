package com.inheritanceday2;

public class Computer extends Device{
	public void boot() {
		System.out.println("Rebooting....");
	}
	
}
