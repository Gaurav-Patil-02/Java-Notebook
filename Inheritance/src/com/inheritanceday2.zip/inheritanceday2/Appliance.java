package com.inheritanceday2;

public class Appliance {
	public void turnOn() {
		System.out.println("Turning On....");
	}
}
