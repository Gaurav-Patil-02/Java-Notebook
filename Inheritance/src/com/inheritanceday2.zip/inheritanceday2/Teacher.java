package com.inheritanceday2;

public class Teacher {
	public void teach() {
		System.out.println("Teacher is Teaching...");
	}
}
