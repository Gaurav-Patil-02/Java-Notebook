package com.questionsOnMethods;

public class Addition {
	public static void add(int a, int b) {
		System.out.println("Addition : " + (a + b));
	}
	public static void main(String[] args) {
		Addition.add(34, 40);
	}
}
