package com.questionsOnMethods;

public class ASCII {
	
	public static void findASCII(char ch) {
		int ascii = ch;
		System.out.println("ASCII : " + ascii);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ASCII.findASCII('X');

	}

}
