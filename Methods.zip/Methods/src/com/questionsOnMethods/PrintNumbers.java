package com.questionsOnMethods;

public class PrintNumbers {
	
	public static void print( int n) {
		for(int i = 1; i <= n; i++) {
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PrintNumbers.print(200);

	}

}
