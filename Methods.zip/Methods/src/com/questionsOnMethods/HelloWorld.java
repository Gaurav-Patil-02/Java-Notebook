package com.questionsOnMethods;

public class HelloWorld {
	
	public static void helloWorld() {
		System.out.println("Hello World");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HelloWorld.helloWorld();

	}

}
