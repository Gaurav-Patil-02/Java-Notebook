package com.questionsOnMethods;

public class Cube {
	public static void cube(int n) {
		System.out.println("Cube : "+  n * n * n);
	}
	public static void main(String[] args) {
		Cube.cube(122);
	}
}
