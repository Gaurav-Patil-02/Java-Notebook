package com.questionsOnMethods;

public class Square {
	
	public static void square(int n) {
		System.out.println("sqaure : "+  n * n);
	}
	public static void main(String[] args) {
		Square.square(122);
	}
}
