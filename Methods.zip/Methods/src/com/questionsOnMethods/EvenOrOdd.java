package com.questionsOnMethods;

public class EvenOrOdd {
	
	public static void evenOrOdd(int a) {
		if(a % 2 == 0) {
			System.out.println("Even");
		}else {
			System.out.println("Odd");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EvenOrOdd.evenOrOdd(25);
	}

}
